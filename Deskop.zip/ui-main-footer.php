<footer>
<div class="footer-con-container">
	<div class="footer-con-overlay darkmode-header">
		<div class="wavebar-con-container">
			<div class="wavebar-con-wrap">
			  <div class="wavebar-svg-object"></div>
			  <div class="wavebar-svg-object"></div>
			</div>
		</div>
		<div class="footer-con-header">
			<div class="footer-con-outer">
				<div class="footer-con-inner">
					<div class="footer-ico-logo darkmode-footer-logo">
					</div>
					<table class="footer-table-out">
					<tr>
						<td>
							<div class="footer-table-in">
								<div class="footer-con-bound">
									<div class="footer-tx1-bound">
										<span>Основное</span>
									</div>
									<div class="footer-tx2-bound">
										<a href="https://github.com/Pranya-lang" target="_blank">
										<span>GITHUB</span>
										</a>
									</div>
									<div class="footer-tx2-bound">
										<a href="https://discord.gg/7BMdzvV" target="_blank">>
										<span>DISCROD</span>
										</a>
									</div>
									<div class="footer-tx2-bound">
										<a href="https://www.youtube.com/channel/UCFzFkjvs1B5Nxu1HS9gN3Eg" target="_blank">
										<span>YOUTUBE</span>
										</a>
									</div>
									</div>
								</div>
							</div>
						</td>

		<div class='footer-con-credits'>
			<div class="footer-con-outer">
				<div class="footer-con-inner">
					<div class="footer-con-foot">
						<div class="footer-tx1-developer">
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
</footer>