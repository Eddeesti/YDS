<link rel="stylesheet" type="text/css" href="/lib/css/anim.css?v2"/>
<link rel="stylesheet" type="text/css" href="/lib/css/dark.css?v2"/>
<link rel="stylesheet" type="text/css" href="/lib/css/main.css?v2"/>
<link rel="stylesheet" type="text/css" href="/lib/css/scale.css?v2"/>
<link rel="stylesheet" type="text/css" href="/lib/css/debug.css?v2"/>
