<div class='menu-con-message fade-out-onload'>
	<div class='menu-tx1-message toggle-message fade-out-onload'>
		<span>We are currently experiencing a higher server volume than usual. We sincerely apologize for any inconveniences.</span>
	</div>
</div>
	<div class="content-con-outside">
		<div class="content-con-inside">
			</div>
				</div>
			</div>
		</div>
	</div>
</div>
<div class="window-con-theme">
	<div class="window-bg-theme">
	</div>
	<div class="theme-con-spinner">
		<div class="theme-ico-spinner">
		</div>
	</div>
	<div class="theme-tx1-description pulsate">
		<span>This feature is currently not yet available</span>
	</div>
	<div class="wavebar-con-container-theme">
		<div class="wavebar-con-wrap">
			<div class="wavebar-svg-object">
			</div>
			<div class="wavebar-svg-object">
			</div>
		</div>
	</div>
</div>
<div class="theme-btn-close toggle-theme">
</div>
	</div>
</div>
<div class='menu-con-container'>
	<div class="menu-con-backdrop">
	</div>	<div class="menu-btn-settngs toggle-ss">
		<div class="menu-tx1-settigs">
		</div>
	</div>
	<div class="menu-con-outer">
		<div class="menu-con-inner">
			<div class="menu-con-logo">
				<a href='/'>
				<div class="menu-ico-logo">
				</div>
				</a>
			</div>
			<div class="mobile-menu-btn-open toggle-mobilemenu">
			</div>
			<a href='https://vk.com/unium35' target="_blank">>
			<div class="menu-btn-select">
				<span>Vk</span>
			</div>
			</a>
			<a href='https://github.com/Pranya-lang' target="_blank">
			<div class="menu-btn-select">
				<span>GitHub</span>
			</div>
			</a>
			<a href='https://discord.gg/7BMdzvV' target="_blank">
			<div class="menu-btn-select">
				<span>Discord</span>
			</div>
			</a>
			<a href='https://www.youtube.com/channel/UCFzFkjvs1B5Nxu1HS9gN3Eg' target="_blank">
			<div class="menu-btn-select">
				<span>YouTube</span>
			</div>
			</a>
					</div>
					</a>
				</div>
			</div>
		</div>
	</div>
</div>
<div class='mobile-menu-con-container popup-mobilemenu' style="display:none;">
	<div class="menu-con-backdrop-2">
	</div>
	<div class='mobile-menu-con-scroll'>
		<div class="mobile-menu-con-outter">
			<div class="mobile-menu-con-inner" style="overflow: hidden !important;">
			</div>
							<a href="/">
				<div class='mobile-menu-btn-select'>
					<span>Home</span>
				</div>
				</a>
				<a href="/blog">
				<div class='mobile-menu-btn-select'>
					<span>Blog</span>
				</div>
				</a>
				<a href="/about">
				<div class='mobile-menu-btn-select'>
					<span>About</span>
				</div>
				</a>
				<a href="/compatibility">
				<div class='mobile-menu-btn-select'>
					<span>Compatibility</span>
				</div>
				</a>
				<a href="/download">
				<div class='mobile-menu-btn-select'>
					<span>Download</span>
				</div>
				</a>
				<a href="/quickstart">
				<div class='mobile-menu-btn-select'>
					<span>Quickstart</span>
				</div>
				</a>
				<a href="/roadmap">
				<div class='mobile-menu-btn-select'>
					<span>Roadmap</span>
				</div>
				</a>
				<a href="/disclaimer">
				<div class='mobile-menu-btn-select'>
					<span>Disclaimer</span>
				</div>
				</a>
				<a href="/faq">
				<div class='mobile-menu-btn-select'>
					<span>FAQs</span>
				</div>
				</a>
				<a href="https://github.com/rpcs3" target="_blank">
				<div class='mobile-menu-btn-select'>
					<span>GitHub</span>
				</div>
				</a>
				<a href="https://forums.rpcs3.net" target="_blank">
				<div class='mobile-menu-btn-select'>
					<span>Forum</span>
				</div>
				</a>
				<a href='https://wiki.rpcs3.net'>
				<div class='mobile-menu-btn-select'>
					<span>Wiki</span>
				</div>
				</a>
				<a href="https://discord.me/RPCS3" target="_blank">
				<div class='mobile-menu-btn-select'>
					<span>Discord</span>
				</div>
				</a>
				<a href="https://www.youtube.com/channel/UCz3-0QxNr4S4gK0xaWy7exQ/videos" target="_blank">
				<div class='mobile-menu-btn-select'>
					<span>YouTube</span>
				</div>
				</a>
		</div>
	</div>
</div>